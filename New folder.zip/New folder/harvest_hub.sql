-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Nov 29, 2023 at 07:40 AM
-- Server version: 5.0.37
-- PHP Version: 5.2.2

-- 
-- Database: `harvest_hub`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `contact`
-- 

CREATE TABLE `contact` (
  `cid` tinyint(50) NOT NULL auto_increment,
  `cname` varchar(50) binary NOT NULL,
  `cemail` varchar(50) binary NOT NULL,
  `csubject` varchar(50) binary NOT NULL,
  `cmessage` varchar(400) binary NOT NULL,
  PRIMARY KEY  (`cid`)
) TYPE=InnoDB AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `contact`
-- 

INSERT INTO `contact` (`cid`, `cname`, `cemail`, `csubject`, `cmessage`) VALUES 
(2, 0x64616e75, 0x64616e7540676d61696c2e636f6d, 0x766567697461626c6573, 0x31207061636b206f662074616d61746f657320);

-- --------------------------------------------------------

-- 
-- Table structure for table `facility`
-- 

CREATE TABLE `facility` (
  `fid` tinyint(50) NOT NULL auto_increment,
  `facility` varchar(50) binary NOT NULL,
  `discription` varchar(50) binary NOT NULL,
  PRIMARY KEY  (`fid`)
) TYPE=InnoDB AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `facility`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `login`
-- 

CREATE TABLE `login` (
  `loginid` tinyint(30) NOT NULL auto_increment,
  `username` varchar(30) binary NOT NULL,
  `password` varchar(30) binary NOT NULL,
  PRIMARY KEY  (`loginid`)
) TYPE=InnoDB AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `login`
-- 

INSERT INTO `login` (`loginid`, `username`, `password`) VALUES 
(1, 0x73756c616b7368616e, 0x313233);

-- --------------------------------------------------------

-- 
-- Table structure for table `signup`
-- 

CREATE TABLE `signup` (
  `stid` tinyint(50) NOT NULL auto_increment,
  `susername` varchar(50) binary NOT NULL,
  `semail` varchar(50) binary NOT NULL,
  `spassword` varchar(50) binary NOT NULL,
  `aaddress` varchar(50) binary NOT NULL,
  PRIMARY KEY  (`stid`)
) TYPE=InnoDB AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `signup`
-- 

INSERT INTO `signup` (`stid`, `susername`, `semail`, `spassword`, `aaddress`) VALUES 
(1, 0x68617269, 0x6861726940676d61696c2e636f6d, 0x30303939, 0x3636206b6f6e646176696c206a6166666e6120);

-- --------------------------------------------------------

-- 
-- Table structure for table `usignup`
-- 

CREATE TABLE `usignup` (
  `usid` tinyint(50) NOT NULL auto_increment,
  `ufullname` varchar(50) NOT NULL,
  `uemail` varchar(60) NOT NULL,
  `uusername` varchar(70) NOT NULL,
  `upassword` varchar(60) NOT NULL,
  PRIMARY KEY  (`usid`)
) TYPE=InnoDB AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `usignup`
-- 

INSERT INTO `usignup` (`usid`, `ufullname`, `uemail`, `uusername`, `upassword`) VALUES 
(2, 'danu', 'danu@gmail.com', 'danudanu', '1234');
