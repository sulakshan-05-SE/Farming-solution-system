<?php

@mysql_connect("localhost","root","")or die ("can not be connected");
@mysql_select_db('harvest_Hub') or die ("can not be connected");

?>